
<?php
	session_start();
    error_reporting (E_ALL ^ E_NOTICE);
    require_once 'Controller/EmployeeController.php';
	$_SESSION["Employees"] = "Personal Details";
    
?>
<html>
<body>
	<h5><?php echo $err_db;?></h5>
	<form action="" onsubmit = "return validateEmployee()"  method="post" >
	<fieldset>
		<table>
		<tr><td> <h1><b> <?php echo $_SESSION["Employees"];?><b> </h1></td></tr><br>
		
</table>
<hr><br>
		<table>
			
		<tr>
				<td>Username:</td>
				<td><input id="uName" name="userName" type="text" onfocusout="checkUserName(this)"value="<?php echo $userName;?>"><br>
				<span id="err_uName"><?php echo $err_userName;?></span>
				</td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input id="pass" name="password" type="password" value="<?php echo $password;?>"><br>
					<span id="err_pass"><?php echo $err_password;?></span> 
				</td>
			</tr>
			<tr>
				<td>Full Name:</td>
				<td><input id="name" name="name" type="text" value="<?php echo $name;?>"><br>
					<span id = "err_name"><?php echo $err_name;?></span> 
				</td>
			</tr>
		
			<tr>
				<td>Mobile No:</td>
				<td>
					<input id="ph" name="PhoneNumber" type="text" value="<?php echo $PhoneNumber;?>">
					<br>
					<span id="err_ph"><?php echo $err_PhoneNumber;?></span> 
				</td>
			</tr>
			<tr>
				<td>Date of Birth:</td>
				<td>
					<input id="DB" name="DateOfBirth" type="date" value="<?php echo $DB;?>">
					<br>
					<span id="err_ph"><?php echo $err_DB;?></span>
				</td>
			</tr>
			
			<tr>
				<td> 
				<a href="page2.php" ><input type="submit" name ="next" value="next"></a>
				</td>
			</tr>
		</table>
</fieldset>
	</form>
			
</body>
</html>