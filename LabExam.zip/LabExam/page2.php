<?php
	session_start();
    error_reporting (E_ALL ^ E_NOTICE);
    require_once 'Controller/EmployeeController.php';
	$_SESSION["Employees"] = "Education";
    
?>
<html>
<body>
	<h5><?php echo $err_db;?></h5>
	<form action="" onsubmit = "return validateEmployee()"  method="post" >
	<fieldset>
		<table>
		<tr><td> <h1><b> <?php echo $_SESSION["Employees"];?><b> </h1></td></tr><br>
		
</table>
<hr><br>
		<table>
			
		<tr>
				<td>University:</td>
				<td><input id="Uni" name="Uni" type="text" onfocusout="checkUserName(this)"value="<?php echo $Uni;?>"><br>
				<span id="err_Uni"><?php echo $err_Uni;?></span>
				</td>
			</tr>
			<tr>
				<td>Degree:</td>
				<td><input id="Deg" name="Deg" type="text" value="<?php echo $Deg;?>"><br>
					<span id="err_Deg"><?php echo $err_Deg;?></span> 
				</td>
			</tr>
			<tr>
				<td>Major:</td>
				<td><input id="Maj" name="Maj" type="text" value="<?php echo $Maj;?>"><br>
					<span id = "err_Maj"><?php echo $err_Maj;?></span> 
				</td>
			</tr>
		
			<tr>
				<td>Results:</td>
				<td>
					<input id="Res" name="Res" type="text" value="<?php echo $Res;?>">
					<br>
					<span id="err_Res"><?php echo $err_Res;?></span> 
				</td>
			</tr>
			<tr>
				<td>Passing Year:</td>
				<td>
					<input id="PY" name="PY" type="date" value="<?php echo $PY;?>">
					<br>
					<span id="err_PY"><?php echo $err_PY;?></span>
				</td>
			</tr>
			
			<tr>
				<td> 
				<input type="submit" name ="next" value="next">
				</td>
			</tr>
		</table>
</fieldset>
	</form>
			
</body>
</html>