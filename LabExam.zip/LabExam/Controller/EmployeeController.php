<?php
	require_once "Models/db_config.php";

	$name="";
	$err_name="";
	$userName="";
	$err_userName="";
	$password="";
	$err_password="";
	$PhoneNumber="";
	$err_PhoneNumber="";
	$DB="";
	$err_DB="";
	$Uni="";
	$err_Uni="";
	$userDeg="";
	$err_Deg="";
	$Maj="";
	$err_Maj="";
	$Res="";
	$err_Res="";
	$PY="";
	$err_PY="";
	
	$hasError=false;
	
	
	if(isset($_POST["next"]))
	{
		
		if(empty($_POST["name"])){
			$hasError=true;
			$err_name="Name Required";
		}
		elseif (strlen($_POST["name"]) <=2){
			$hasError = true;
			$err_name = "Name must be greater than 2 characters";
		}
		elseif (is_numeric($_POST["name"]))
		{
			$hasError = true;
			$err_name = "Name can't be numeric!!";
		}
		else{
			$name = $_POST["name"];
		}
		
		if(empty($_POST["userName"])){
			$hasError=true;
			$err_userName="UserName Required";
		}
		elseif (strlen($_POST["userName"]) <6){
			$hasError = true;
			$err_userName = "UserName must be greater than 6 characters";
		}
		elseif (strpos($_POST["userName"]," ")){
			$hasError = true;
			$err_userName = "UserName can't take space!!!";
		}
		else
		{
			$userName = $_POST["userName"];
		}
		if(empty($_POST["password"]))
		{
		$hasError = true;
		$err_password = "Password required";
		}

		else if((strlen($_POST["password"])< 8))
		{
		$hasError = true;
		$err_password = "Password requires minimum 8 characters";
		}
		else
		{
			$password = $_POST["password"];
		}
	
		
		
		if(empty($_POST["PhoneNumber"])){
			$hasError = true;
			$err_PhoneNumber = "PhoneNumber Required!!!";
		}
		elseif(is_numeric($_POST["PhoneNumber"])){
			$PhoneNumber = $_POST["PhoneNumber"];
		}
		else{
			$hasError = true;
			$err_PhoneNumber = "Please enter a numeric value!!!";
		}
		
		if(empty($_POST["DateOfBirth"])){
			$hasError = true;
			$err_DB = "date of birth required!!!";
		}
		elseif(is_numeric($_POST["DateOfBirth"])){
			$DB = $_POST["DateOfBirth"];
		}
		else{
			$hasError = true;
			$err_DB = "Please enter a numeric value!!!";
		}
		
		
		if(!$hasError){
			$rs= insertEmployee($name,$userName,$password,$PhoneNumber,$DB);
			if($rs === true)
			{
				header("Location: page2.php");
			}
			//$err_db= "Email or Password Invalid";
			$err_db= $rs;
		}
		
	}

	if(isset($_POST["page2"]))
	{
		
		if(empty($_POST["Uni"])){
			$hasError=true;
			$err_Uni="University Required";
		}
		elseif (strlen($_POST["Uni"]) <=2){
			$hasError = true;
			$err_Uni = "University must be greater than 2 characters";
		}
		elseif (is_numeric($_POST["Uni"]))
		{
			$hasError = true;
			$err_Uni = "University can't be numeric!!";
		}
		else{
			$Uni = $_POST["Uni"];
		}
		
		if(empty($_POST["Deg"])){
			$hasError=true;
			$err_Deg="Deg Required";
		}
		elseif (strlen($_POST["Deg"]) <6){
			$hasError = true;
			$err_Deg = "Degree must be greater than 6 characters";
		}
		elseif (strpos($_POST["Deg"]," ")){
			$hasError = true;
			$err_Deg = "Degree can't take space!!!";
		}
		else
		{
			$Deg = $_POST["Deg"];
		}
		if(empty($_POST["Maj"]))
		{
		$hasError = true;
		$err_Maj = "Major required";
		}

		else if((strlen($_POST["Maj"])< 8))
		{
		$hasError = true;
		$err_Maj = "Major requires minimum 8 characters";
		}
		else
		{
			$Maj = $_POST["Maj"];
		}
	
		
		
		if(empty($_POST["Res"])){
			$hasError = true;
			$err_Res = "Results Required!!!";
		}
		elseif(is_numeric($_POST["Res"])){
			$Res = $_POST["Res"];
		}
		else{
			$hasError = true;
			$err_Res = "Please enter a numeric value!!!";
		}
		
		if(empty($_POST["PY"])){
			$hasError = true;
			$err_PY = "Passing Year required!!!";
		}
		elseif(is_numeric($_POST["PY"])){
			$PY = $_POST["PY"];
		}
		else{
			$hasError = true;
			$err_PY = "Please enter a numeric value!!!";
		}
		
		
		if(!$hasError){
			$rs= insertEmployee($Uni,$Deg,$Maj,$Res,$PY);
			if($rs === true)
			{
				header("Location: page2.php");
			}
			//$err_db= "Email or Password Invalid";
			$err_db= $rs;
		}
		
	}
	
	
	
	function insertEmployee($name,$userName,$password,$DB,$Uni,$Deg,$Maj,$Res,$PY)
	{
		$query= "insert into Employee values(Null,'$name','$userName','$password','$phoneNumber','$DB','$Uni','$Deg','$Maj','$Res','$PY')";
		return execute($query);
	}
	function updateEmployee($name,$userName,$password,$DB,$Uni,$Deg,$Maj,$Res,$PY)
	{
		$query = "update Employee set name ='$name',userName = '$userName',phoneNumber ='$PhoneNumber',DB='$DB',University = '$Uni', Degree ='$Deg', Major ='$Maj', Results ='$Res', Passing_Year ='$PY' where EmployeeId = '$id'";
		return execute($query);
	}

?>